﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;

namespace ProductionOptimization
{
    public partial class MainWindow : Window
    {
        public class MaterialUsage
        {
            public string Name { get; set; }
            public double ProductAConsumption { get; set; }
            public double ProductBConsumption { get; set; }
            public double Stock { get; set; }
        }

        public class ResourceUsageResult
        {
            public string Name { get; set; }
            public double Used { get; set; }
            public double Available { get; set; }
            public double Remaining { get; set; }
        }

        public MainWindow()
        {
            InitializeComponent();
            LoadInitialData();
        }

        private void LoadInitialData()
        {
            var materials = new List<MaterialUsage>
            {
                new MaterialUsage { Name = "Сырье 1", ProductAConsumption = 2, ProductBConsumption = 3, Stock = 21 },
                new MaterialUsage { Name = "Сырье 2", ProductAConsumption = 1, ProductBConsumption = 0, Stock = 4 },
                new MaterialUsage { Name = "Сырье 3", ProductAConsumption = 0, ProductBConsumption = 1, Stock = 6 },
                new MaterialUsage { Name = "Сырье 4", ProductAConsumption = 2, ProductBConsumption = 1, Stock = 10 }
            };

            MaterialsGrid.ItemsSource = materials;
        }

        private void CalculateOptimalPlan_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Получаем данные о доходах
                double incomeA = double.Parse(ProductAIncome.Text);
                double incomeB = double.Parse(ProductBIncome.Text);

                // Получаем данные о материалах
                var materials = MaterialsGrid.ItemsSource as List<MaterialUsage>;
                if (materials == null || materials.Count == 0)
                {
                    MessageBox.Show("Нет данных о материалах");
                    return;
                }

                if (incomeA < 0 || incomeB < 0)
                {
                    MessageBox.Show("Доходы не могут быть отрицательными.", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Решаем задачу симплекс-методом
                var solution = SolveProductionProblem(materials, incomeA, incomeB);

                // Отображаем результаты
                OptimalProductA.Text = solution.Item1.ToString();
                OptimalProductB.Text = solution.Item2.ToString();
                MaxIncome.Text = $"{solution.Item3} руб.";

                // Отображаем использование ресурсов
                ShowResourcesUsage(materials, solution.Item1, solution.Item2);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private Tuple<double, double, double> SolveProductionProblem(List<MaterialUsage> materials, double incomeA, double incomeB)
        {
            // Количество переменных (x - изделия A, y - изделия B)
            int varCount = 2;

            // Количество ограничений (по количеству видов сырья)
            int constraintCount = materials.Count;

            // Коэффициенты целевой функции (максимизация дохода)
            double[] objectiveCoefficients = { incomeA, incomeB };

            // Матрица ограничений (A*x <= b)
            double[,] constraintMatrix = new double[constraintCount, varCount];
            double[] constraintLimits = new double[constraintCount];

            for (int i = 0; i < constraintCount; i++)
            {
                constraintMatrix[i, 0] = materials[i].ProductAConsumption;
                constraintMatrix[i, 1] = materials[i].ProductBConsumption;
                constraintLimits[i] = materials[i].Stock;
            }

            // Реализация симплекс-метода
            var solution = SimplexMethod.SolveMaximization(varCount, constraintCount,
                objectiveCoefficients, constraintMatrix, constraintLimits);

            double x = Math.Floor(solution[0]);
            double y = Math.Floor(solution[1]);

            double maxIncome = x * incomeA + y * incomeB;

            return Tuple.Create(x, y, maxIncome);
        }

        private void ShowResourcesUsage(List<MaterialUsage> materials, double productA, double productB)
        {
            var usageResults = new List<ResourceUsageResult>();

            foreach (var material in materials)
            {
                double used = material.ProductAConsumption * productA + material.ProductBConsumption * productB;
                usageResults.Add(new ResourceUsageResult
                {
                    Name = material.Name,
                    Used = used,
                    Available = material.Stock,
                    Remaining = material.Stock - used
                });
            }

            ResourcesUsageGrid.ItemsSource = usageResults;
        }

private void LoadData_Click(object sender, RoutedEventArgs e)
{
    try
    {
        var openDialog = new Microsoft.Win32.OpenFileDialog
        {
            Filter = "Text files (*.txt)|*.txt"
        };

        if (openDialog.ShowDialog() == true)
        {
            var lines = File.ReadAllLines(openDialog.FileName);

            var materials = new List<MaterialUsage>();
            foreach (var line in lines)
            {
                // Ожидаемый формат строки: "Сырье 1,2,3,21"
                var parts = line.Split(',');
                if (parts.Length == 4)
                {
                    materials.Add(new MaterialUsage
                    {
                        Name = parts[0],
                        ProductAConsumption = double.Parse(parts[1]),
                        ProductBConsumption = double.Parse(parts[2]),
                        Stock = double.Parse(parts[3])
                    });
                }
            }

            MaterialsGrid.ItemsSource = materials;

            OptimalProductA.Text = "0";
            OptimalProductB.Text = "0";
            MaxIncome.Text = "0 руб.";
            ResourcesUsageGrid.ItemsSource = null;
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show($"Ошибка при загрузке: {ex.Message}");
    }
}


        private void ResetData_Click(object sender, RoutedEventArgs e)
        {
            LoadInitialData();
            OptimalProductA.Text = "0";
            OptimalProductB.Text = "0";
            MaxIncome.Text = "0 руб.";
            ResourcesUsageGrid.ItemsSource = null;
        }

        private void SaveResultsToFile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var saveDialog = new Microsoft.Win32.SaveFileDialog
                {
                    Filter = "Text files (*.txt)|*.txt",
                    FileName = "Результаты_оптимизации.txt"
                };

                if (saveDialog.ShowDialog() == true)
                {
                    using (var writer = new StreamWriter(saveDialog.FileName))
                    {
                        writer.WriteLine("Результаты оптимизации:");
                        writer.WriteLine($"Изделие A: {OptimalProductA.Text}");
                        writer.WriteLine($"Изделие B: {OptimalProductB.Text}");
                        writer.WriteLine($"Максимальный доход: {MaxIncome.Text}");

                        writer.WriteLine("\nИспользование ресурсов:");
                        var usage = ResourcesUsageGrid.ItemsSource as List<ResourceUsageResult>;
                        if (usage != null)
                        {
                            foreach (var res in usage)
                            {
                                writer.WriteLine($"{res.Name}: Использовано {res.Used}, Осталось {res.Remaining}, Доступно {res.Available}");
                            }
                        }
                    }

                    MessageBox.Show("Результаты успешно сохранены!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}");
            }
        }

    }

    public static class SimplexMethod
{
    private const double Epsilon = 1e-10;
    
    public static double[] SolveMaximization(int varCount, int constraintCount,
        double[] objectiveCoefficients, double[,] constraintMatrix, double[] constraintLimits)
    {
        // Проверка входных данных
        if (varCount <= 0 || constraintCount <= 0)
            throw new ArgumentException("Invalid variable or constraint count");
        
        // Количество искусственных переменных
        int totalVars = varCount + constraintCount;
        
        // Инициализация симплекс-таблицы
        double[,] table = new double[constraintCount + 1, totalVars + 1];
        
        // Заполнение ограничений
        for (int i = 0; i < constraintCount; i++)
        {
            for (int j = 0; j < varCount; j++)
            {
                table[i, j] = constraintMatrix[i, j];
            }
            
            // Добавляем slack-переменные
            table[i, varCount + i] = 1;
            
            // Правая часть ограничения
            table[i, totalVars] = constraintLimits[i];
        }
        
        // Заполнение целевой функции
        for (int j = 0; j < varCount; j++)
        {
            table[constraintCount, j] = -objectiveCoefficients[j];
        }
        
        // Основная фаза симплекс-метода
        while (true)
        {
            // Находим входящую переменную (наибольший по модулю отрицательный коэффициент)
            int pivotCol = -1;
            for (int j = 0; j < totalVars; j++)
            {
                if (table[constraintCount, j] < -Epsilon && 
                    (pivotCol == -1 || table[constraintCount, j] < table[constraintCount, pivotCol]))
                {
                    pivotCol = j;
                }
            }
            
            // Если все коэффициенты неотрицательные - решение найдено
            if (pivotCol == -1) break;
            
            // Находим исходящую переменную (минимальное отношение)
            int pivotRow = -1;
            double minRatio = double.MaxValue;
            for (int i = 0; i < constraintCount; i++)
            {
                if (table[i, pivotCol] > Epsilon)
                {
                    double ratio = table[i, totalVars] / table[i, pivotCol];
                    if (ratio < minRatio)
                    {
                        minRatio = ratio;
                        pivotRow = i;
                    }
                }
            }
            
            // Если не нашли подходящую строку - задача неограничена
            if (pivotRow == -1)
                throw new InvalidOperationException("Problem is unbounded");
            
            // Нормализация pivot-строки
            double pivotValue = table[pivotRow, pivotCol];
            for (int j = 0; j <= totalVars; j++)
            {
                table[pivotRow, j] /= pivotValue;
            }
            
            // Исключение pivot-столбца из других строк
            for (int i = 0; i <= constraintCount; i++)
            {
                if (i != pivotRow && Math.Abs(table[i, pivotCol]) > Epsilon)
                {
                    double factor = table[i, pivotCol];
                    for (int j = 0; j <= totalVars; j++)
                    {
                        table[i, j] -= factor * table[pivotRow, j];
                    }
                }
            }
        }
        
        // Извлечение решения
        double[] solution = new double[varCount];
        for (int j = 0; j < varCount; j++)
        {
            bool isBasic = false;
            double value = 0;
            int basicRow = -1;
            
            for (int i = 0; i < constraintCount; i++)
            {
                if (Math.Abs(table[i, j] - 1) < Epsilon)
                {
                    if (basicRow == -1)
                    {
                        basicRow = i;
                        value = table[i, totalVars];
                        isBasic = true;
                    }
                    else
                    {
                        isBasic = false; // Вырожденный случай
                    }
                }
                else if (Math.Abs(table[i, j]) > Epsilon)
                {
                    isBasic = false;
                }
            }
            
            solution[j] = isBasic ? value : 0;
        }
        
        return solution;
    }
}
}